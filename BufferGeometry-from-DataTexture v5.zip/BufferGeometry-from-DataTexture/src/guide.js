import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";

console.clear();

let scene = new THREE.Scene();
scene.background = new THREE.Color(0x404040);
let camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 1000);
camera.position.set(3, 5, 8).setLength(10);
camera.lookAt(scene.position);
let renderer = new THREE.WebGLRenderer({
  antialias: true
});
renderer.setSize(innerWidth, innerHeight);
//renderer.setClearColor(0x404040);
document.body.appendChild(renderer.domElement);
window.addEventListener("resize", (event) => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

let controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;

let light = new THREE.DirectionalLight(0xffffff, 0.8);
light.position.set(0.25, 1, 0.75);
scene.add(light, new THREE.AmbientLight(0xffffff, 0.2));


let g = new THREE.PlaneGeometry(10, 10, 100, 70).rotateX(-Math.PI * 0.5);
let m = new THREE.MeshBasicMaterial({
  wireframe: true,
  vertexColors: true,
  onBeforeCompile: shader => {
    shader.uniforms.vertTexture = m.userData.vertTexture;
    shader.vertexShader = `
      uniform sampler2D vertTexture;
      ${shader.vertexShader}
    `.replace(
      `#include <begin_vertex>`,
      `#include <begin_vertex>
        float vertIdx = float(gl_VertexID);
        ivec2 texSize = textureSize(vertTexture, 0);
        float texWidth = float(texSize.x);
        float texHeight = float(texSize.y);
        int colIdx = int(floor(vertIdx / texWidth));
        int rowIdx = int(mod(vertIdx, texWidth));
        vec3 posData = texelFetch(vertTexture, ivec2(rowIdx, colIdx), 0).rgb;
        
        // just to be sure we're working with the data from texture, let the plane be wavy
        posData.y = sin(posData.x);
        
        transformed = posData;
        
        // painting by uv
        vColor = vec3(uv, 0);
      `
    );
    console.log(shader.vertexShader);
  }
});
m.userData = {
  vertTexture: {value: makeTexture(g)}
}
console.log(m)
let o = new THREE.Mesh(g, m);
scene.add(o);

function makeTexture(g){
  
  let vertAmount = g.attributes.position.count;
  let texWidth = Math.ceil(Math.sqrt(vertAmount));
  let texHeight = Math.ceil(vertAmount / texWidth);
  
  let data = new Float32Array(texWidth * texHeight * 4);
  
  for(let i = 0; i < vertAmount; i++){
    data[i * 4 + 0] = g.attributes.position.getX(i);
    data[i * 4 + 1] = g.attributes.position.getY(i);
    data[i * 4 + 2] = g.attributes.position.getZ(i);
    data[i * 4 + 3] = 0;
  }
  
  let dataTexture = new THREE.DataTexture(data, texWidth, texHeight, THREE.RGBAFormat, THREE.FloatType);
  dataTexture.needsUpdate = true;
  
  return dataTexture;
}


renderer.setAnimationLoop((_) => {
  controls.update();
  renderer.render(scene, camera);
});
